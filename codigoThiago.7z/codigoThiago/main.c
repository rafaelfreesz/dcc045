#include <stdio.h>
#include "LexicalAnalyzer.h"

//Print Functions
void printToken(Token* token);
void printLexicalAnalyser();
void printSymbolTables();
const char* translateState(int state);

int main(int argc, char *argv[ ]) {

    if(argc>1){
         buildLexicalAnalyzer(argv[1]);
    }else{
        //DoSomething
    }

    buildLexemBuffer();
    
    Token* token=nextToken();
    while(token->token!=CMMEOF){
       printToken(token);
       free(token);
       token=nextToken();
    }

    printToken(token);
    printSymbolTables();

    delete reservedWordsSymbolTable;
    delete literalsSymbolTable;
    delete identifiersSymbolTable;

    return 0;
}

//Function to print Token data
void printToken(Token* token){

    if(token->token >= 561 && token->token <= 581){

        printf("%s\n", translateState(token->token));

    }else{


        char* tokemLexem= getLexem(token->lexemIndex, token->lexemIndex + token->lexemSize);
        if(token->token==ID || token->token==NUMINT || token->token==NUMFLOAT || token->token==LITERAL){
            printf("%s.%s\n", translateState(token->token), tokemLexem);
        }else{
            printf("%s\n", translateState(token->token));
        }

        free(tokemLexem);
    }
}

//Function to print Lexical Analyzer data for test
void printLexicalAnalyser(){
    LexicalAnalyser* lex=getLexPointer();
    printf("--------------Lexical Analyzer Data-----------\n");
    printf("StreamLength: %d\n",lex->streamLength);
    printf("BufferIndex: %d\n",lex->bufferIndex);
    printf("StreamBuffer:\n");
    for(int i=0;i<lex->streamLength;i++){
        printf("%c",lex->stremBuffer[i]);
    }
    printf("\n-------------------------\n");
}

//Function to print Symbol Table data
void printSymbolTables(){

    printf("\nSYMBOL TABLE: RESERVED WORDS\n");
    printf("----------------------------------------\n");
    printf("LEXEM                   NUMERIC TOKEN\n\n");

    SymbolTable* pointer=getReservedWordsSymbolTablePointer();

    for (int i = 0; i< TABSIZE; i++) {
        
        if(pointer->symbolTable[i] != NULL){

            int whiteSpacesNumber = 19 - strlen(pointer->symbolTable[i]->lexem) + 6;
            printf(" %s", pointer->symbolTable[i]->lexem);
            for(int j = 0; j < whiteSpacesNumber; j++) printf(" ");
            printf("%d", pointer->symbolTable[i]->token);

            TabEntry* currentEntry = pointer->symbolTable[i];
            while(currentEntry->prox != NULL){

                whiteSpacesNumber = 19 - strlen(currentEntry->prox->lexem) + 6;
                printf(" %s", currentEntry->prox->lexem);
                for(int j = 0; j < whiteSpacesNumber; j++) printf(" ");
                printf("%d", currentEntry->prox->token);
                currentEntry = currentEntry->prox;
            }
            printf("\n");
        }
    }

    pointer=getIdentifiersSymbolTable();

    printf("\nSYMBOL TABLE: IDENTIFIER\n");
    printf("----------------------------------------\n");
    printf("LEXEM                   \n\n");

    for (int i = 0; i< TABSIZE; i++) {
        
        if(pointer->symbolTable[i] != NULL){

            int whiteSpacesNumber = 19 - strlen(pointer->symbolTable[i]->lexem) + 6;
            printf(" %s", pointer->symbolTable[i]->lexem);
            
            TabEntry* currentEntry = pointer->symbolTable[i];
            while(currentEntry->prox != NULL){

                whiteSpacesNumber = 19 - strlen(currentEntry->prox->lexem) + 6;
                printf(" %s", currentEntry->prox->lexem);
                currentEntry = currentEntry->prox;
            }
            printf("\n");
        }
    }
    
    pointer=getLiteralsSymbolTable();

    printf("\nSYMBOL TABLE: LITERALS\n");
    printf("----------------------------------------\n");
    printf("LEXEM                   \n\n");

    for (int i = 0; i< TABSIZE; i++) {
        
        if(pointer->symbolTable[i] != NULL){

            int whiteSpacesNumber = 19 - strlen(pointer->symbolTable[i]->lexem) + 6;
            printf(" %s", pointer->symbolTable[i]->lexem);

            TabEntry* currentEntry = pointer->symbolTable[i];
            while(currentEntry->prox != NULL){

                whiteSpacesNumber = 19 - strlen(currentEntry->prox->lexem) + 6;
                printf(" %s", currentEntry->prox->lexem);

                currentEntry = currentEntry->prox;
            }
            printf("\n");
        }
    }

    

}

//Translate a state or Hash number to referred string
const char* translateState(int state){
    switch (state) {
        case 1:
            return "COLON";
        case 2:
            return "MOD";
        case 3:
            return "PLUS";
        case 4:
            return "MULT";
        case 5:
            return "CMMEOF";
        case 14:
            return "NOT";
        case 13:
            return "NEQ";
        case 17:
            return "GREAT";
        case 16:
            return "GEQ";
        case 20:
            return "LEQ";
        case 19:
            return "LESS";
        case 23:
            return "EQ";
        case 22:
            return "ASSIGN";
        case 27:
            return "DIV";
        case 35:
            return "LITERAL";
        case 11:
            return "RIGHTPARENTHESES";
        case 10:
            return "LEFTPARENTHESES";
        case 9:
            return "RIGHTBRACKET";
        case 8:
            return "LEFTBRACKET";
        case 7:
            return "RIGHTBRACE";
        case 6:
            return "LEFTBRACE";
        case 56:
            return "ID";
        case 54:
            return "POINT";
        case 53:
            return "NUMFLOAT";
        case 46:
            return "NUMINT";
        case 43:
            return "POINTER";
        case 44:
            return "MINUS";
        case 40:
            return "AND";
        case 41:
            return "AMBERSAND";
        case 37:
            return "OR";
        case 38:
            return "PIPE";
        case 57:
            return "SEMICOLON";
        case 58:
            return "COMMA";
        case 561:
            return "TYPEDEF";
        case 562:
            return "STRUCT";
        case 563:
            return "LONG";
        case 564:
            return "INT";
        case 565:
            return "FLOAT";
        case 566:
            return "BOOL";
        case 567:
            return "CHAR";
        case 568:
            return "DOUBLE";
        case 569:
            return "IF";
        case 570:
            return "WHILE";
        case 571:
            return "SWITCH";
        case 572:
            return "BREAK";
        case 573:
            return "PRINT";
        case 574:
            return "READLN";
        case 575:
            return "RETURN";
        case 576:
            return "THROW";
        case 577:
            return "TRY";
        case 578:
            return "CATCH";
        case 579:
            return "CASE";
        case 580:
            return "FOR";
        case 30:
            return "UNEXPECTEDEOF";
        case 48:
            return "MALFORMEDNUMBER";
        case 49:
            return "UNEXPECTEDENTRY";

    }
    return NULL;
}